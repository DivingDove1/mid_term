print("測試 import pyautogui...")

try:
    import pyautogui

    print("✅ import 成功")
    print(f"   版本: {pyautogui.__version__}")

    # 測試 locateOnScreen
    print("\n測試 locateOnScreen...")
    try:
        result = pyautogui.locateOnScreen("assets/popup_text.png", confidence=0.9)
        print(f"✅ 找到了: {result}")
    except pyautogui.ImageNotFoundException:
        print("❌ 沒找到（但這是正常的，表示函數可以執行）")
    except Exception as e:
        print(f"❌ 錯誤: {e}")

except ImportError as e:
    print(f"❌ import 失敗: {e}")
except NameError as e:
    print(f"❌ NameError: {e}")
