import pyautogui
import time
import config

print("=== 測試彈窗偵測與關閉按鈕位置 ===\n")
print("請確保遊戲彈窗已出現")
print("3 秒後開始偵測...\n")
time.sleep(3)

try:
    # 偵測縮放係數
    screenshot = pyautogui.screenshot()
    screen_size = pyautogui.size()
    scale_factor = screenshot.size[0] / screen_size[0]
    print(f"縮放係數: {scale_factor}\n")

    # 尋找彈窗文字
    popup_location = pyautogui.locateOnScreen(config.POPUP_TEXT_IMAGE, confidence=0.55)

    if popup_location:
        print(f"✅ 找到彈窗文字！")
        print(f"   位置: {popup_location}")

        text_center_x = popup_location.left + popup_location.width // 2
        text_center_y = popup_location.top + popup_location.height // 2
        print(f"   中心點（實際座標）: ({text_center_x}, {text_center_y})")

        # 測試不同的偏移量
        test_offsets = [
            (160, -100, "預設"),
            (150, -60, "測試1"),
            (100, -100, "測試2"),
            (130, -70, "測試3"),
        ]

        for offset_x, offset_y, label in test_offsets:
            close_x_actual = text_center_x + offset_x
            close_y_actual = text_center_y + offset_y

            # 轉換邏輯座標
            if scale_factor != 1.0:
                close_x = close_x_actual / scale_factor
                close_y = close_y_actual / scale_factor
            else:
                close_x = close_x_actual
                close_y = close_y_actual

            print(f"\n{label}: 偏移 ({offset_x}, {offset_y})")
            print(f"  滑鼠將移到: ({close_x:.0f}, {close_y:.0f})")
            print("  移動中... 請觀察是否在關閉按鈕上")

            pyautogui.moveTo(close_x, close_y, duration=1)
            time.sleep(3)

        print("\n請記下哪個偏移量最準確，並更新到 config.py 中的:")
        print("  CLOSE_BUTTON_OFFSET_X")
        print("  CLOSE_BUTTON_OFFSET_Y")

    else:
        print("❌ 找不到彈窗文字")
        print("\n可能原因:")
        print("  1. popup_text.png 圖片不存在或路徑錯誤")
        print("  2. 彈窗沒有出現")
        print("  3. 圖片與螢幕上的文字不匹配")
        print("  4. confidence 值太高")

except Exception as e:
    print(f"❌ 錯誤: {e}")
    import traceback

    traceback.print_exc()
