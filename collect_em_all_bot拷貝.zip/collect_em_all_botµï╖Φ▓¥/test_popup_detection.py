import pyautogui
import time
import config

print("=== 彈窗偵測測試 ===\n")
print("請確保遊戲已結束並顯示「不能再移動」彈窗")
print("5 秒後開始測試...\n")
time.sleep(5)

# 測試 1：檢查檔案
import os

print(f"[測試 1] 檢查圖片檔案")
print(f"  路徑: {config.POPUP_TEXT_IMAGE}")
print(f"  存在: {os.path.exists(config.POPUP_TEXT_IMAGE)}")

if not os.path.exists(config.POPUP_TEXT_IMAGE):
    print("\n❌ 圖片不存在！請確認路徑")
    exit()

# 測試 2：截圖並儲存
print(f"\n[測試 2] 截圖當前畫面")
screenshot = pyautogui.screenshot()
screenshot.save("current_screen.png")
print(f"  已儲存: current_screen.png")
print(f"  尺寸: {screenshot.size}")

# 測試 3：載入參考圖片
print(f"\n[測試 3] 載入參考圖片")
from PIL import Image

ref_image = Image.open(config.POPUP_TEXT_IMAGE)
print(f"  參考圖片尺寸: {ref_image.size}")

# 測試 4：嘗試不同的 confidence 值
print(f"\n[測試 4] 嘗試不同的信心度值")

confidence_values = [0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3]

for conf in confidence_values:
    try:
        print(f"\n  嘗試 confidence={conf}...", end=" ")
        location = pyautogui.locateOnScreen(config.POPUP_TEXT_IMAGE, confidence=conf)
        print(f"✅ 找到了！位置: {location}")
        break
    except pyautogui.ImageNotFoundException:
        print(f"❌ 沒找到")
    except Exception as e:
        print(f"❌ 錯誤: {e}")

# 測試 5：顯示提示
print("\n[測試 5] 建議")
print("  1. 打開 current_screen.png，確認彈窗是否清晰可見")
print("  2. 比對 current_screen.png 和 popup_text.png")
print("  3. 確認兩者的「不能再移動」文字是否一致")
print("  4. 如果不一致，重新截取 popup_text.png")
